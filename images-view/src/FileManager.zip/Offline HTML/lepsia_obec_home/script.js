﻿<!DOCTYPE html>

<html lang="en" xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta charset="utf-8" />
	<title>Empty Offline HTML page</title>
	<meta http-equiv="X-UA-Compatible" content="IE=edge" />
	<meta name="viewport" content="initial-scale=1, user-scalable=no" />
</head>
<body>
        <div id="qrcode"></div>

	<script>
               jquery('#qrcode').qrcode("this plugin is great");
	</script>
        <script src="JSBridge.js"></script>
        <script type="text/javascript" src="jquery.min.js"></script>
        <script type="text/javascript" src="jquery.qrcode.min.js"></script>
</body>
</html>
