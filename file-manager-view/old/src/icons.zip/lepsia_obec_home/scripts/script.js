﻿
window.addEventListener('DOMContentLoaded', () => {
    window.addEventListener('scroll', () => {
        let divEl = document.querySelector('#scroll-opacity');
        let opacity = positionToOpacity(Math.round(divEl.getBoundingClientRect().top), Math.round(divEl.getBoundingClientRect().height));
        divEl.style.opacity = opacity;
    })
});

function positionToOpacity(position, height) { //position range: 90
    console.log(position, height);
    return position.map(90, (height - Math.abs(position) - 60) * (-1), 1, 0);
}

Number.prototype.map = function (in_min, in_max, out_min, out_max) {
    return (this - in_min) * (out_max - out_min) / (in_max - in_min) + out_min;
}
